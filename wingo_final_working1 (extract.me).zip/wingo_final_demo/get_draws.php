<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$host = 'localhost';
$db   = 'wingo';
$user = 'root';    // Change if your MySQL user is different
$pass = '12345678';        // Change if your MySQL password is set
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    echo json_encode([
        "error" => "Database connection failed",
        "details" => $e->getMessage()
    ]);
    exit;
}

// SQL query to fetch latest 10 results
$sql = "SELECT draw_number, result_number, size, color, created_at 
        FROM results 
        ORDER BY created_at DESC 
        LIMIT 10";

try {
    $stmt = $pdo->query($sql);
    $results = $stmt->fetchAll();

    echo json_encode($results);
} catch (PDOException $e) {
    echo json_encode([
        "error" => "Query failed",
        "details" => $e->getMessage()
    ]);
}
?>
