<?php
header('Content-Type: application/json');

$host = 'localhost';
$db = 'wingo';
$user = 'root';
$pass = '12345678';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    // Get latest draw
    $stmt = $pdo->query("SELECT * FROM results ORDER BY id DESC LIMIT 2");
    $rows = $stmt->fetchAll();

    if (count($rows) < 2) {
        echo json_encode(["error" => "Not enough draw data"]);
        exit;
    }

    $latest = $rows[0];
    $prev = $rows[1];

    $last_draw_number = $latest['draw_number'];
    $next_draw_number = generateNextDrawNumber($last_draw_number);

    // Check if prediction exists
    $stmt = $pdo->prepare("SELECT * FROM predictions WHERE last_draw_number = ?");
    $stmt->execute([$last_draw_number]);
    $prediction = $stmt->fetch();

    if ($prediction) {
        echo json_encode([
            "status" => "exists",
            "last_draw_number" => $prediction['last_draw_number'],
            "next_draw_number" => $prediction['next_draw_number'],
            "predicted_number" => $prediction['predicted_number'],
            "predicted_size" => $prediction['predicted_size'],
            "predicted_color" => $prediction['predicted_color'],
            "reason" => explode(" | ", $prediction['reason'])
        ]);
        exit;
    }

    // Predict logic
    $predicted_size = 'Small';
    $reasons = [];

    if ($latest['result_number'] === '0') {
        if ($prev['result_number'] === '0' && $prev['size'] === 'Big') {
            $predicted_size = 'Big';
            $reasons[] = "Last two numbers were 0, previous size was Big.";
        } else {
            $predicted_size = 'Small';
            $reasons[] = "Last number is 0, fallback to Small.";
        }
    } elseif (is_numeric($latest['result_number'])) {
        $num = (int)$latest['result_number'];
        $predicted_size = ($num >= 5) ? 'Small' : 'Big';
        $reasons[] = "Predicted size based on number {$num}.";
    }

    $colors = ['Red', 'Green', 'Blue'];
    $last_color = $latest['color'];
    $index = array_search($last_color, $colors);
    $predicted_color = $colors[($index + 1) % 3];
    $reasons[] = "Rotate color from $last_color to $predicted_color";

    // Insert new prediction
    $insert = $pdo->prepare("
        INSERT INTO predictions
        (last_draw_number, next_draw_number, predicted_number, predicted_size, predicted_color, reason)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $insert->execute([
        $last_draw_number,
        $next_draw_number,
        '*',
        $predicted_size,
        $predicted_color,
        implode(" | ", $reasons)
    ]);

    echo json_encode([
        "status" => "success",
        "last_draw_number" => $last_draw_number,
        "next_draw_number" => $next_draw_number,
        "predicted_size" => $predicted_size,
        "predicted_color" => $predicted_color,
        "reason" => $reasons
    ]);

} catch (PDOException $e) {
    echo json_encode([
        "error" => "Database connection failed",
        "details" => $e->getMessage()
    ]);
}

function generateNextDrawNumber($current) {
    $num = ltrim($current, '*');
    if (!is_numeric($num)) return "*000001";
    return "*" . str_pad(((int)$num + 1), 6, "0", STR_PAD_LEFT);
}
